package com.example.array2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    Button ver;
    ListView listView;
    String titulos[]={"Sakura Haruno","Sasuke Uchiha","Madara Uchiha","Pain(Yahiko)","Obito Uchiha","Sasori","Gaara","Deidara","Konan","Hidan" };
    String descripciones[]={"Ninja Medico","Desertor de Konoha","Resucitado","Líder de Akatsuki",
            "Principal responsable de la 4ta Guerra","Miembro Aktsuki","Kazekage","Miembro Akatsuki","Miembro de Akatsuki","Miembro de Akatsuki"};
    int avatar[]={R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d,R.drawable.e,R.drawable.f,R.drawable.g,R.drawable.h,R.drawable.i,R.drawable.j};

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ver = (Button) findViewById(R.id.ver);
        ver.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent ver = new Intent(MainActivity.this, ver.class);
                startActivity(ver);
            }
        });
        //instanciar vista
        listView = findViewById(R.id.lista);
        //instanciar elementos que contiene la lista mediante SetAdapter
        listView.setAdapter(new Datos(this, titulos, descripciones, avatar));


    }
}